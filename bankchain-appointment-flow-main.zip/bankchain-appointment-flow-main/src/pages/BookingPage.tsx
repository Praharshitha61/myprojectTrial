import React, { useState } from 'react';
import { format } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { 
  CalendarDays, 
  Clock, 
  Users, 
  FileText, 
  CheckCircle2, 
  CreditCard, 
  Home, 
  BanknoteIcon, 
  CheckSquare, 
  Smartphone, 
  User, 
  Key, 
  ShieldCheck, 
  Briefcase,
  FileCheck,
  CircleDotIcon,
  CircleXIcon,
  AlertCircle,
  FileInput,
  ClipboardList
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";

const bankServiceGroups = [
  {
    id: 'account',
    name: 'Account Services',
    icon: <User className="h-5 w-5" />,
    services: [
      { 
        id: 'account_opening', 
        name: 'Account Opening', 
        signature: 'Bank Officer',
        documents: [
          'ID proof (Aadhaar, PAN)',
          'Address proof',
          'Passport-size photo',
          'Initial deposit'
        ]
      },
      { 
        id: 'account_closure', 
        name: 'Account Closure', 
        signature: 'Branch Manager',
        documents: [
          'Account closure form',
          'Passbook',
          'Cheque book (if issued)',
          'ID proof'
        ]
      },
      { 
        id: 'kyc_update', 
        name: 'KYC Update', 
        signature: 'Bank Officer',
        documents: [
          'Updated ID proof',
          'Address proof'
        ]
      },
      { 
        id: 'nominee_update', 
        name: 'Nominee Addition/Update', 
        signature: 'Relationship Manager',
        documents: [
          'Nomination form',
          'ID proof of account holder'
        ]
      }
    ]
  },
  {
    id: 'deposit',
    name: 'Deposit Services',
    icon: <BanknoteIcon className="h-5 w-5" />,
    services: [
      { 
        id: 'fixed_deposit', 
        name: 'Fixed/Recurring Deposit', 
        signature: 'Bank Officer',
        documents: [
          'Account details',
          'Amount to deposit',
          'ID proof'
        ]
      },
      { 
        id: 'interest_certificate', 
        name: 'Interest Certificate', 
        signature: 'Bank Officer',
        documents: [
          'Account number',
          'Written request'
        ]
      },
      { 
        id: 'fd_lien', 
        name: 'FD Lien for Loan', 
        signature: 'Branch Manager',
        documents: [
          'FD receipt',
          'Loan application',
          'ID proof'
        ]
      }
    ]
  },
  {
    id: 'loan',
    name: 'Loan Services',
    icon: <Home className="h-5 w-5" />,
    services: [
      { 
        id: 'personal_loan', 
        name: 'Personal/Business Loan', 
        signature: 'Loan Officer',
        documents: [
          'Loan application',
          'ID proof',
          'Address proof',
          'Income proof',
          'Bank statements'
        ]
      },
      { 
        id: 'home_loan', 
        name: 'Home Loan', 
        signature: 'Credit Manager',
        documents: [
          'Property documents',
          'ID/address/income proof',
          'Bank statements',
          'Loan application'
        ]
      },
      { 
        id: 'vehicle_loan', 
        name: 'Vehicle Loan', 
        signature: 'Loan Officer',
        documents: [
          'Quotation of vehicle',
          'ID proof',
          'Income proof',
          'Address proof'
        ]
      },
      { 
        id: 'loan_closure', 
        name: 'Loan Closure', 
        signature: 'Branch Manager',
        documents: [
          'Loan account number',
          'ID proof'
        ]
      },
      { 
        id: 'loan_statement', 
        name: 'Loan Statement/Foreclosure', 
        signature: 'Loan Officer',
        documents: [
          'Loan account number',
          'Request letter'
        ]
      }
    ]
  },
  {
    id: 'cheque',
    name: 'Cheque Services',
    icon: <CheckSquare className="h-5 w-5" />,
    services: [
      { 
        id: 'cheque_book', 
        name: 'Cheque Book Issuance', 
        signature: 'Bank Officer',
        documents: [
          'Cheque book request form',
          'Account number'
        ]
      },
      { 
        id: 'stop_payment', 
        name: 'Cheque Stop Payment', 
        signature: 'Assistant Manager',
        documents: [
          'Cheque details',
          'Request letter'
        ]
      },
      { 
        id: 'bounce_clarification', 
        name: 'Cheque Bounce Clarification', 
        signature: 'Branch Manager',
        documents: [
          'Bounced cheque',
          'Bank statement'
        ]
      }
    ]
  },
  {
    id: 'card',
    name: 'Card Services',
    icon: <CreditCard className="h-5 w-5" />,
    services: [
      { 
        id: 'card_issuance', 
        name: 'Debit/Credit Card Issuance', 
        signature: 'Bank Officer',
        documents: [
          'Card application form',
          'Account number',
          'ID proof'
        ]
      },
      { 
        id: 'card_block', 
        name: 'Card Block/Replacement', 
        signature: 'Assistant Manager',
        documents: [
          'Card number',
          'FIR copy (if stolen)',
          'ID proof'
        ]
      },
      { 
        id: 'limit_increase', 
        name: 'Credit Card Limit Increase', 
        signature: 'Credit Manager',
        documents: [
          'Income proof',
          'Credit card details'
        ]
      }
    ]
  },
  {
    id: 'online',
    name: 'Online & Mobile Banking',
    icon: <Smartphone className="h-5 w-5" />,
    services: [
      { 
        id: 'net_banking', 
        name: 'Net Banking Activation', 
        signature: 'Bank Officer',
        documents: [
          'Account number',
          'Mobile number',
          'ID proof'
        ]
      },
      { 
        id: 'password_reset', 
        name: 'Password Reset Request', 
        signature: 'Assistant Manager',
        documents: [
          'Account number',
          'ID proof'
        ]
      },
      { 
        id: 'app_issues', 
        name: 'Mobile App Setup Issues', 
        signature: 'Bank Officer',
        documents: [
          'Account number',
          'Mobile number'
        ]
      }
    ]
  },
  {
    id: 'govt',
    name: 'Government-Linked Services',
    icon: <ShieldCheck className="h-5 w-5" />,
    services: [
      { 
        id: 'pan_linking', 
        name: 'PAN Linking', 
        signature: 'Bank Officer',
        documents: [
          'PAN card',
          'Account number'
        ]
      },
      { 
        id: 'aadhaar_seeding', 
        name: 'Aadhaar Seeding', 
        signature: 'Bank Officer',
        documents: [
          'Aadhaar card',
          'Account number'
        ]
      },
      { 
        id: 'subsidy', 
        name: 'Subsidy Processing', 
        signature: 'Assistant Manager',
        documents: [
          'Aadhaar',
          'Scheme form',
          'Account number'
        ]
      }
    ]
  },
  {
    id: 'nri',
    name: 'NRI Services',
    icon: <Briefcase className="h-5 w-5" />,
    services: [
      { 
        id: 'nri_account', 
        name: 'NRI Account Opening', 
        signature: 'NRI Relationship Manager',
        documents: [
          'Passport',
          'Visa',
          'Address proof',
          'Overseas address proof'
        ]
      },
      { 
        id: 'repatriation', 
        name: 'Repatriation Services', 
        signature: 'Branch Manager',
        documents: [
          'Repatriation form',
          'Purpose proof',
          'NRI account details'
        ]
      }
    ]
  },
  {
    id: 'locker',
    name: 'Locker Services',
    icon: <Key className="h-5 w-5" />,
    services: [
      { 
        id: 'locker_allotment', 
        name: 'Locker Allotment', 
        signature: 'Branch Manager',
        documents: [
          'Locker agreement form',
          'KYC documents'
        ]
      },
      { 
        id: 'locker_surrender', 
        name: 'Locker Surrender', 
        signature: 'Branch Manager',
        documents: [
          'Locker surrender form',
          'Key',
          'ID proof'
        ]
      }
    ]
  },
  {
    id: 'misc',
    name: 'Miscellaneous Services',
    icon: <FileCheck className="h-5 w-5" />,
    services: [
      { 
        id: 'dd_pay_order', 
        name: 'Demand Draft/Pay Order', 
        signature: 'Bank Officer',
        documents: [
          'Request form',
          'Amount',
          'ID proof'
        ]
      },
      { 
        id: 'balance_certificate', 
        name: 'Balance Certificate/Statement', 
        signature: 'Bank Officer',
        documents: [
          'Account number',
          'Request form'
        ]
      },
      { 
        id: 'solvency', 
        name: 'Solvency Certificate', 
        signature: 'Branch Manager',
        documents: [
          'Request form',
          'Asset proof',
          'ID proof'
        ]
      },
      { 
        id: 'standing_instructions', 
        name: 'Standing Instructions', 
        signature: 'Bank Officer',
        documents: [
          'Instruction form',
          'Account number'
        ]
      },
      { 
        id: 'signature_verification', 
        name: 'Signature Verification', 
        signature: 'Assistant Manager',
        documents: [
          'Request letter',
          'ID proof'
        ]
      }
    ]
  }
];

const getAllServices = () => {
  return bankServiceGroups.flatMap(group => group.services);
};

const timeSlots = [
  '9:00 AM', '10:00 AM', '11:00 AM', 
  '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM'
];

const bankAdvisors = [
  { id: 'john', name: 'John Smith', role: 'Bank Officer', available: true },
  { id: 'sarah', name: 'Sarah Johnson', role: 'Assistant Manager', available: true },
  { id: 'michael', name: 'Michael Chen', role: 'Branch Manager', available: false },
  { id: 'emily', name: 'Emily Williams', role: 'Relationship Manager', available: true },
  { id: 'david', name: 'David Wilson', role: 'Loan Officer', available: true },
  { id: 'olivia', name: 'Olivia Martinez', role: 'Credit Manager', available: true },
  { id: 'james', name: 'James Taylor', role: 'NRI Relationship Manager', available: true },
];

type BookingStep = 'service' | 'date' | 'details' | 'confirmation';

const BookingPage = () => {
  const [step, setStep] = useState<BookingStep>('service');
  const [selectedServiceGroup, setSelectedServiceGroup] = useState<string>('');
  const [selectedService, setSelectedService] = useState<string>('');
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [time, setTime] = useState<string>('');
  const [advisor, setAdvisor] = useState<string>('');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    notes: '',
  });
  const { toast } = useToast();

  const getRequiredSignature = () => {
    const allServices = getAllServices();
    const service = allServices.find(s => s.id === selectedService);
    return service ? service.signature : '';
  };

  const getFilteredAdvisors = () => {
    const requiredSignature = getRequiredSignature();
    return bankAdvisors.filter(advisor => 
      advisor.role === requiredSignature && advisor.available
    );
  };

  const getSelectedServiceName = () => {
    const allServices = getAllServices();
    const service = allServices.find(s => s.id === selectedService);
    return service ? service.name : '';
  };

  const getSelectedServiceGroupName = () => {
    const group = bankServiceGroups.find(g => g.id === selectedServiceGroup);
    return group ? group.name : '';
  };

  const isRequiredEmployeeAvailable = () => {
    const requiredSignature = getRequiredSignature();
    return bankAdvisors.some(advisor => 
      advisor.role === requiredSignature && advisor.available
    );
  };

  const getRequiredEmployeeCount = () => {
    const requiredSignature = getRequiredSignature();
    return bankAdvisors.filter(advisor => advisor.role === requiredSignature).length;
  };

  const getAvailableEmployeeCount = () => {
    const requiredSignature = getRequiredSignature();
    return bankAdvisors.filter(advisor => 
      advisor.role === requiredSignature && advisor.available
    ).length;
  };

  const getRequiredDocuments = () => {
    const allServices = getAllServices();
    const service = allServices.find(s => s.id === selectedService);
    return service ? service.documents : [];
  };

  const handleNext = () => {
    if (step === 'service' && selectedService) {
      setStep('date');
    } else if (step === 'date' && date && time) {
      setStep('details');
    } else if (step === 'details' && formData.name && formData.email && formData.phone) {
      setTimeout(() => {
        setStep('confirmation');
        toast({
          title: "Appointment Confirmed!",
          description: "Your appointment has been securely recorded on our blockchain.",
        });
      }, 1500);
    }
  };

  const handleBack = () => {
    if (step === 'date') setStep('service');
    if (step === 'details') setStep('date');
    if (step === 'confirmation') setStep('details');
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleServiceGroupChange = (value: string) => {
    setSelectedServiceGroup(value);
    setSelectedService('');
  };

  const handleServiceChange = (value: string) => {
    setSelectedService(value);
    setAdvisor('');
  };

  const renderStepIndicator = () => {
    return (
      <div className="flex justify-center mb-8">
        <div className="flex items-center">
          <div className={`rounded-full h-10 w-10 flex items-center justify-center ${step === 'service' ? 'bg-bank-primary text-white' : 'bg-bank-light text-bank-primary'}`}>
            <FileText className="h-5 w-5" />
          </div>
          <div className={`h-1 w-8 ${step !== 'service' ? 'bg-bank-primary' : 'bg-gray-300'}`}></div>
          <div className={`rounded-full h-10 w-10 flex items-center justify-center ${step === 'date' ? 'bg-bank-primary text-white' : step === 'service' ? 'bg-gray-300 text-gray-500' : 'bg-bank-light text-bank-primary'}`}>
            <CalendarDays className="h-5 w-5" />
          </div>
          <div className={`h-1 w-8 ${step === 'details' || step === 'confirmation' ? 'bg-bank-primary' : 'bg-gray-300'}`}></div>
          <div className={`rounded-full h-10 w-10 flex items-center justify-center ${step === 'details' ? 'bg-bank-primary text-white' : step === 'confirmation' ? 'bg-bank-light text-bank-primary' : 'bg-gray-300 text-gray-500'}`}>
            <Users className="h-5 w-5" />
          </div>
          <div className={`h-1 w-8 ${step === 'confirmation' ? 'bg-bank-primary' : 'bg-gray-300'}`}></div>
          <div className={`rounded-full h-10 w-10 flex items-center justify-center ${step === 'confirmation' ? 'bg-bank-primary text-white' : 'bg-gray-300 text-gray-500'}`}>
            <CheckCircle2 className="h-5 w-5" />
          </div>
        </div>
      </div>
    );
  };

  const renderServiceSelection = () => {
    return (
      <Card className="w-full max-w-3xl mx-auto shadow-lg border-t-4 border-t-bank-secondary">
        <CardHeader className="bg-gradient-to-r from-bank-light to-white">
          <CardTitle className="text-bank-primary text-xl">Select a Service</CardTitle>
          <CardDescription>Choose the banking service you need assistance with</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="mb-6">
            <Label className="text-bank-primary font-medium">Service Category</Label>
            <Select value={selectedServiceGroup} onValueChange={handleServiceGroupChange}>
              <SelectTrigger className="mt-2 border-bank-light focus:ring-bank-secondary">
                <SelectValue placeholder="Select a service category" />
              </SelectTrigger>
              <SelectContent>
                {bankServiceGroups.map((group) => (
                  <SelectItem key={group.id} value={group.id}>
                    <div className="flex items-center">
                      {group.icon}
                      <span className="ml-2">{group.name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selectedServiceGroup && (
            <div>
              <Label className="text-bank-primary font-medium">Service Type</Label>
              <RadioGroup 
                value={selectedService} 
                onValueChange={handleServiceChange} 
                className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2"
              >
                {bankServiceGroups
                  .find(group => group.id === selectedServiceGroup)?.services
                  .map((service) => {
                    const employeesWithRole = bankAdvisors.filter(a => a.role === service.signature);
                    const availableEmployees = employeesWithRole.filter(a => a.available);
                    const isAvailable = availableEmployees.length > 0;
                    
                    return (
                      <div 
                        key={service.id} 
                        className={`flex items-center space-x-2 border rounded-lg p-4 cursor-pointer hover:border-bank-primary transition-colors ${isAvailable ? 'bg-white' : 'bg-gray-50'}`}
                      >
                        <RadioGroupItem value={service.id} id={service.id} />
                        <Label htmlFor={service.id} className="flex-1 cursor-pointer">
                          <div className="flex justify-between items-start">
                            <div>
                              {service.name}
                              <div className="text-xs text-gray-500 mt-1 flex items-center">
                                <span>Required: </span>
                                <Badge variant="outline" className="ml-1 text-xs font-normal">
                                  {service.signature}
                                </Badge>
                              </div>
                            </div>
                            <div className="flex items-center">
                              {isAvailable ? (
                                <Badge className="bg-green-100 text-green-800 hover:bg-green-200 flex items-center gap-1 ml-2">
                                  <CircleDotIcon className="h-3 w-3 text-green-500" />
                                  <span className="text-xs">Available</span>
                                </Badge>
                              ) : (
                                <Badge className="bg-red-100 text-red-800 hover:bg-red-200 flex items-center gap-1 ml-2">
                                  <CircleXIcon className="h-3 w-3 text-red-500" />
                                  <span className="text-xs">Unavailable</span>
                                </Badge>
                              )}
                            </div>
                          </div>
                        </Label>
                      </div>
                    );
                  })}
              </RadioGroup>
            </div>
          )}
          
          {selectedService && (
            <div className="mt-6 border rounded-md p-4 bg-blue-50 border-blue-100">
              <h3 className="text-sm font-medium text-bank-primary flex items-center mb-2">
                <ClipboardList className="h-4 w-4 mr-2 text-bank-secondary" />
                Required Documents:
              </h3>
              <ul className="pl-6 mt-2 space-y-1">
                {getRequiredDocuments().map((doc, index) => (
                  <li key={index} className="text-sm text-gray-700 flex items-start">
                    <FileInput className="h-4 w-4 mr-2 mt-0.5 text-bank-secondary" />
                    <span>{doc}</span>
                  </li>
                ))}
              </ul>
              <p className="text-xs text-gray-500 mt-3 italic">
                Please bring these documents to your appointment
              </p>
            </div>
          )}
          
          {selectedService && !isRequiredEmployeeAvailable() && (
            <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-md flex items-start">
              <AlertCircle className="h-5 w-5 text-amber-500 mr-2 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-sm text-amber-800">
                  No {getRequiredSignature()} is currently available for this service.
                </p>
                <p className="text-xs text-amber-700 mt-1">
                  You can still book an appointment, but you may need to be flexible with scheduling.
                </p>
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between bg-gray-50 rounded-b-lg border-t">
          <div className="text-sm text-gray-500">
            {selectedService && (
              <span>
                {getAvailableEmployeeCount()} of {getRequiredEmployeeCount()} {getRequiredSignature()}s available
              </span>
            )}
          </div>
          <Button 
            onClick={handleNext}
            disabled={!selectedService}
            className="bg-bank-primary hover:bg-bank-accent transition-colors"
          >
            Next
          </Button>
        </CardFooter>
      </Card>
    );
  };

  const renderDateSelection = () => {
    const filteredAdvisors = getFilteredAdvisors();
    const requiredSignature = getRequiredSignature();

    return (
      <Card className="w-full max-w-3xl mx-auto shadow-lg border-t-4 border-t-bank-secondary">
        <CardHeader className="bg-gradient-to-r from-bank-light to-white">
          <CardTitle className="text-bank-primary text-xl">Select Date & Time</CardTitle>
          <CardDescription>Choose your preferred appointment date and time</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label className="text-bank-primary font-medium">Select Date</Label>
              <div className="mt-2 border rounded-md p-2 border-bank-light shadow-sm">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  disabled={(date) => {
                    const day = date.getDay();
                    return date < new Date(new Date().setHours(0, 0, 0, 0)) || day === 0 || day === 6;
                  }}
                  className="p-3 pointer-events-auto"
                />
              </div>
            </div>
            <div>
              <div className="mb-6">
                <Label className="text-bank-primary font-medium">Select Time</Label>
                <Select value={time} onValueChange={setTime}>
                  <SelectTrigger className="mt-2 border-bank-light focus:ring-bank-secondary">
                    <SelectValue placeholder="Select time slot" />
                  </SelectTrigger>
                  <SelectContent>
                    {timeSlots.map((slot) => (
                      <SelectItem key={slot} value={slot}>
                        <div className="flex items-center">
                          <Clock className="mr-2 h-4 w-4 text-bank-secondary" />
                          {slot}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label className="text-bank-primary font-medium">
                  <div className="flex items-center justify-between">
                    <span>Select {requiredSignature}</span>
                    <Badge className="font-normal">
                      {filteredAdvisors.length} available
                    </Badge>
                  </div>
                </Label>
                <Select value={advisor} onValueChange={setAdvisor}>
                  <SelectTrigger className="mt-2 border-bank-light focus:ring-bank-secondary">
                    <SelectValue placeholder={`Select a ${requiredSignature}`} />
                  </SelectTrigger>
                  <SelectContent>
                    {filteredAdvisors.length > 0 ? (
                      filteredAdvisors.map((adv) => (
                        <SelectItem 
                          key={adv.id} 
                          value={adv.id}
                        >
                          <div className="flex items-center">
                            <div className="mr-2 flex items-center">
                              {adv.available ? (
                                <CircleDotIcon className="h-3 w-3 text-green-500" />
                              ) : (
                                <CircleXIcon className="h-3 w-3 text-red-500" />
                              )}
                            </div>
                            <span>{adv.name}</span>
                          </div>
                        </SelectItem>
                      ))
                    ) : (
                      <SelectItem value="none" disabled>
                        <div className="flex items-center">
                          <CircleXIcon className="h-3 w-3 text-red-500 mr-2" />
                          <span>No {requiredSignature}s available</span>
                        </div>
                      </SelectItem>
                    )}
                  </SelectContent>
                </Select>
                {filteredAdvisors.length === 0 && (
                  <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-md flex items-start">
                    <AlertCircle className="h-5 w-5 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-red-800">
                      No {requiredSignature}s are currently available. Please contact the bank or try a different service.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between bg-gray-50 rounded-b-lg border-t">
          <Button variant="outline" onClick={handleBack} className="border-bank-light hover:bg-bank-light/50">
            Back
          </Button>
          <Button 
            onClick={handleNext}
            disabled={!date || !time || (filteredAdvisors.length > 0 && !advisor)}
            className="bg-bank-primary hover:bg-bank-accent transition-colors"
          >
            Next
          </Button>
        </CardFooter>
      </Card>
    );
  };

  const renderDetailsForm = () => {
    return (
      <Card className="w-full max-w-3xl mx-auto shadow-lg border-t-4 border-t-bank-secondary">
        <CardHeader className="bg-gradient-to-r from-bank-light to-white">
          <CardTitle className="text-bank-primary text-xl">Your Details</CardTitle>
          <CardDescription>Please provide your contact information</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="name" className="text-bank-primary font-medium">Full Name</Label>
              <Input
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                placeholder="John Doe"
                required
                className="border-bank-light focus:ring-bank-secondary"
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="email" className="text-bank-primary font-medium">Email</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="johndoe@example.com"
                  required
                  className="border-bank-light focus:ring-bank-secondary"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="phone" className="text-bank-primary font-medium">Phone Number</Label>
                <Input
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  placeholder="(123) 456-7890"
                  required
                  className="border-bank-light focus:ring-bank-secondary"
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="notes" className="text-bank-primary font-medium">Additional Notes (Optional)</Label>
              <Input
                id="notes"
                name="notes"
                value={formData.notes}
                onChange={handleInputChange}
                placeholder="Any specific requirements or questions..."
                className="border-bank-light focus:ring-bank-secondary"
              />
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between bg-gray-50 rounded-b-lg border-t">
          <Button variant="outline" onClick={handleBack} className="border-bank-light hover:bg-bank-light/50">
            Back
          </Button>
          <Button 
            onClick={handleNext}
            disabled={!formData.name || !formData.email || !formData.phone}
            className="bg-bank-primary hover:bg-bank-accent transition-colors"
          >
            Confirm Appointment
          </Button>
        </CardFooter>
      </Card>
    );
  };

  const renderConfirmation = () => {
    const selectedServiceName = getSelectedServiceName();
    const selectedServiceGroupName = getSelectedServiceGroupName();
    const selectedAdvisorName = bankAdvisors.find(a => a.id === advisor)?.name || 'Any available advisor';
    const requiredSignature = getRequiredSignature();
    const selectedAdvisor = bankAdvisors.find(a => a.id === advisor);
    const requiredDocuments = getRequiredDocuments();

    return (
      <Card className="w-full max-w-3xl mx-auto shadow-lg">
        <CardHeader className="bg-green-50 rounded-t-lg border-b border-green-100">
          <div className="flex justify-center mb-4">
            <div className="rounded-full bg-green-100 p-3">
              <CheckCircle2 className="h-8 w-8 text-green-600" />
            </div>
          </div>
          <CardTitle className="text-center text-green-800">Appointment Confirmed!</CardTitle>
          <CardDescription className="text-center text-green-700">
            Your appointment has been scheduled and securely recorded on our blockchain.
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid gap-4">
            <div className="bg-bank-light/30 rounded-lg p-5 shadow-inner">
              <h3 className="font-medium text-bank-primary mb-3 flex items-center">
                <FileCheck className="mr-2 h-5 w-5 text-bank-secondary" />
                Appointment Details
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-start space-x-3">
                  <FileText className="h-5 w-5 text-bank-secondary mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-bank-primary">Service Category</p>
                    <p className="text-sm text-gray-600">{selectedServiceGroupName}</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <FileText className="h-5 w-5 text-bank-secondary mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-bank-primary">Service</p>
                    <p className="text-sm text-gray-600">{selectedServiceName}</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CalendarDays className="h-5 w-5 text-bank-secondary mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-bank-primary">Date</p>
                    <p className="text-sm text-gray-600">{date ? format(date, 'EEEE, MMMM d, yyyy') : ''}</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Clock className="h-5 w-5 text-bank-secondary mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-bank-primary">Time</p>
                    <p className="text-sm text-gray-600">{time}</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Users className="h-5 w-5 text-bank-secondary mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-bank-primary">{requiredSignature}</p>
                    <p className="text-sm text-gray-600 flex items-center">
                      {selectedAdvisorName}
                      {selectedAdvisor && (
                        <span className="ml-2">
                          {selectedAdvisor.available ? (
                            <CircleDotIcon className="h-3 w-3 text-green-500" />
                          ) : (
                            <CircleXIcon className="h-3 w-3 text-red-500" />
                          )}
                        </span>
                      )}
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="border rounded-lg p-5 shadow-sm">
              <h3 className="font-medium text-bank-primary mb-3 flex items-center">
                <ClipboardList className="mr-2 h-5 w-5 text-bank-secondary" />
                Required Documents
              </h3>
              <div className="bg-blue-50 p-4 rounded-md">
                <ul className="pl-2 space-y-2">
                  {requiredDocuments.map((doc, index) => (
                    <li key={index} className="text-sm text-gray-700 flex items-start">
                      <FileInput className="h-4 w-4 mr-2 mt-0.5 text-bank-secondary" />
                      <span>{doc}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <p className="text-xs text-gray-500 mt-2">
                Please bring these documents to your appointment to ensure smooth processing.
              </p>
            </div>
            
            <div className="border rounded-lg p-5 shadow-sm">
              <h3 className="font-medium text-bank-primary mb-3 flex items-center">
                <ShieldCheck className="mr-2 h-5 w-5 text-bank-secondary" />
                Blockchain Transaction
              </h3>
              <div className="bg-gray-100 p-3 rounded-md">
                <p className="text-xs font-mono break-all">
                  Transaction ID: 0x{Math.random().toString(16).substring(2, 42)}
                </p>
              </div>
              <p className="text-xs text-gray-500 mt-2">
                Your appointment details have been securely stored on our blockchain. This record cannot be altered and serves as proof of your booking.
              </p>
            </div>
            
            <div className="text-center text-sm text-gray-600 mt-2 p-4 bg-blue-50 rounded-lg">
              <p className="font-medium text-bank-primary">What's Next?</p>
              <p className="mt-1">A confirmation email has been sent to {formData.email}.</p>
              <p>You will receive a reminder 24 hours before your appointment.</p>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-center bg-gray-50 rounded-b-lg border-t p-6">
          <Button className="bg-bank-primary hover:bg-bank-accent transition-colors" onClick={() => setStep('service')}>
            Book Another Appointment
          </Button>
        </CardFooter>
      </Card>
    );
  };

  return (
    <div className="py-10 px-4 bg-gradient-to-b from-bank-light/30 to-white min-h-screen">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold text-bank-primary">Book Your Appointment</h1>
          <p className="text-gray-600 mt-2 max-w-2xl mx-auto">
            Schedule a secure blockchain-powered appointment with our banking specialists
          </p>
        </div>
        
        {renderStepIndicator()}
        
        {step === 'service' && renderServiceSelection()}
        {step === 'date' && renderDateSelection()}
        {step === 'details' && renderDetailsForm()}
        {step === 'confirmation' && renderConfirmation()}
      </div>
    </div>
  );
};

export default BookingPage;
