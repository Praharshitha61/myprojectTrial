
import React from 'react';
import { Link } from 'react-router-dom';
import { Shield, Lock, Database, CheckCircle2, BookOpen, FileCheck, Blocks, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import BlockchainVisual from '@/components/blockchain/BlockchainVisual';

const AboutBlockchainPage = () => {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-bank-light">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold text-bank-primary tracking-tight">
                Banking Enhanced by <span className="text-bank-secondary">Blockchain</span> Technology
              </h1>
              <p className="mt-6 text-lg text-gray-600">
                Discover how we leverage blockchain technology to provide secure, transparent, and efficient banking appointment services.
              </p>
              <div className="mt-8">
                <Button size="lg" className="bg-bank-primary hover:bg-bank-accent">
                  <Link to="/book" className="flex items-center">
                    Experience It Firsthand <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
              </div>
            </div>
            <div className="p-6 bg-white rounded-lg shadow-lg">
              <h3 className="text-xl font-semibold mb-4 text-bank-primary">Blockchain in Action</h3>
              <BlockchainVisual />
            </div>
          </div>
        </div>
      </section>

      {/* What is Blockchain Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-bank-primary">What is Blockchain?</h2>
            <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
              Blockchain is a distributed ledger technology that enables secure, transparent, and tamper-proof record-keeping.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-bank-light rounded-lg p-6">
              <div className="h-12 w-12 bg-bank-primary bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
                <Database className="h-6 w-6 text-bank-primary" />
              </div>
              <h3 className="text-xl font-semibold text-bank-primary mb-3">Distributed Ledger</h3>
              <p className="text-gray-600">
                Instead of a central database, blockchain distributes identical copies of a ledger across a network of computers, ensuring no single point of failure.
              </p>
            </div>
            
            <div className="bg-bank-light rounded-lg p-6">
              <div className="h-12 w-12 bg-bank-primary bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
                <Lock className="h-6 w-6 text-bank-primary" />
              </div>
              <h3 className="text-xl font-semibold text-bank-primary mb-3">Immutable Records</h3>
              <p className="text-gray-600">
                Once data is recorded on a blockchain, it cannot be altered or deleted, creating a permanent and tamper-proof history of transactions.
              </p>
            </div>
            
            <div className="bg-bank-light rounded-lg p-6">
              <div className="h-12 w-12 bg-bank-primary bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
                <FileCheck className="h-6 w-6 text-bank-primary" />
              </div>
              <h3 className="text-xl font-semibold text-bank-primary mb-3">Smart Contracts</h3>
              <p className="text-gray-600">
                Self-executing contracts with the terms directly written into code, automatically enforcing agreement terms without intermediaries.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How We Use Blockchain Section */}
      <section className="py-16 bg-gradient-to-b from-white to-bank-light">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-bank-primary">How We Use Blockchain</h2>
            <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
              At NaviBank, we leverage blockchain technology to enhance your banking experience in several key ways:
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-start space-x-4">
                <div className="h-12 w-12 bg-bank-primary rounded-full flex items-center justify-center flex-shrink-0">
                  <Blocks className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-bank-primary mb-3">Appointment Booking</h3>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-600">
                        <strong className="text-bank-primary">Immutable Records:</strong> Each appointment booking is recorded on a blockchain, creating a permanent, tamper-proof record.
                      </span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-600">
                        <strong className="text-bank-primary">Smart Contracts:</strong> Automated scheduling and confirmation through code that executes when conditions are met.
                      </span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-600">
                        <strong className="text-bank-primary">Transparency:</strong> All parties can view the same booking information, reducing disputes and confusion.
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-start space-x-4">
                <div className="h-12 w-12 bg-bank-primary rounded-full flex items-center justify-center flex-shrink-0">
                  <Shield className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-bank-primary mb-3">Security & Privacy</h3>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-600">
                        <strong className="text-bank-primary">Enhanced Security:</strong> Cryptographic protection of all transactions and personal data.
                      </span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-600">
                        <strong className="text-bank-primary">Fraud Prevention:</strong> Immutable records make it nearly impossible to falsify or alter appointment information.
                      </span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-600">
                        <strong className="text-bank-primary">Permission Controls:</strong> Only authorized parties can access sensitive information through carefully designed access controls.
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-bank-primary">Frequently Asked Questions</h2>
            <p className="mt-4 text-lg text-gray-600">
              Common questions about our blockchain-enhanced banking services
            </p>
          </div>
          
          <div className="bg-bank-light rounded-lg p-6 shadow-sm">
            <Accordion type="single" collapsible className="space-y-4">
              <AccordionItem value="item-1" className="border-b-0">
                <AccordionTrigger className="text-bank-primary font-medium">
                  Is my personal information secure on the blockchain?
                </AccordionTrigger>
                <AccordionContent className="text-gray-600">
                  Yes. We use a private, permissioned blockchain to store appointment data. Your sensitive personal information is not stored directly on the blockchain—only encrypted references and appointment details. Our system complies with all data protection regulations.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-2" className="border-b-0">
                <AccordionTrigger className="text-bank-primary font-medium">
                  How does blockchain make my appointment more secure?
                </AccordionTrigger>
                <AccordionContent className="text-gray-600">
                  Blockchain provides an immutable, tamper-proof record of your appointment. Once confirmed, the record cannot be altered or deleted, eliminating the risk of unauthorized changes. The distributed nature of blockchain also prevents single points of failure.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-3" className="border-b-0">
                <AccordionTrigger className="text-bank-primary font-medium">
                  Can I see my blockchain transaction record?
                </AccordionTrigger>
                <AccordionContent className="text-gray-600">
                  Yes. Each appointment booking generates a unique transaction ID that you can view in your dashboard. While the technical details are handled in the background, you can see proof that your appointment is securely recorded on our blockchain.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-4" className="border-b-0">
                <AccordionTrigger className="text-bank-primary font-medium">
                  What happens if I need to reschedule or cancel?
                </AccordionTrigger>
                <AccordionContent className="text-gray-600">
                  You can reschedule or cancel through your dashboard. The blockchain will record this change as a new transaction linked to your original appointment, maintaining a complete, transparent history while allowing flexibility.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-5" className="border-b-0">
                <AccordionTrigger className="text-bank-primary font-medium">
                  Do I need any blockchain knowledge to use the system?
                </AccordionTrigger>
                <AccordionContent className="text-gray-600">
                  No. We've designed the interface to be user-friendly and intuitive. The blockchain technology works behind the scenes, providing security and transparency without requiring any technical knowledge from you.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-bank-primary">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center justify-center p-3 bg-white rounded-full mb-6">
            <BookOpen className="h-6 w-6 text-bank-primary" />
          </div>
          <h2 className="text-3xl font-bold text-white">Ready to experience the future of banking?</h2>
          <p className="mt-4 text-xl text-bank-light max-w-3xl mx-auto">
            Book your appointment today and see firsthand how blockchain enhances your banking experience.
          </p>
          <div className="mt-8 space-x-4">
            <Button size="lg" className="bg-white text-bank-primary hover:bg-bank-light">
              <Link to="/book" className="flex items-center">
                Book an Appointment <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button variant="outline" size="lg" className="text-white border-white hover:bg-bank-accent">
              <Link to="/dashboard">View Dashboard</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutBlockchainPage;
