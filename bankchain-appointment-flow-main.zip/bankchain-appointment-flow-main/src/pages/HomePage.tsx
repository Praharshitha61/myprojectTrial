
import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, ArrowRight, Shield, Users, Clock, CheckCircle, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import BlockchainVisual from '@/components/blockchain/BlockchainVisual';
import BlockchainFeatures from '@/components/blockchain/BlockchainFeatures';

const services = [
  {
    title: "Account Opening",
    description: "Schedule an appointment to open a new account with our banking experts.",
    icon: <Users className="h-6 w-6 text-bank-primary" />
  },
  {
    title: "Loan Consultation",
    description: "Meet with our loan specialists to discuss your financing needs and options.",
    icon: <Clock className="h-6 w-6 text-bank-primary" />
  },
  {
    title: "Financial Advice",
    description: "Get personalized financial guidance from our certified advisors.",
    icon: <CheckCircle className="h-6 w-6 text-bank-primary" />
  }
];

const HomePage = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-bank-light to-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold text-bank-primary tracking-tight">
                Banking Appointments <span className="text-bank-secondary">Reimagined</span> with Blockchain
              </h1>
              <p className="mt-6 text-lg text-gray-600">
                Experience the future of banking with our secure, transparent, and efficient appointment booking system powered by blockchain technology.
              </p>
              <div className="mt-8 space-x-4">
                <Button size="lg" className="bg-bank-primary hover:bg-bank-accent">
                  <Link to="/book" className="flex items-center">
                    Book Appointment <Calendar className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button variant="outline" size="lg">
                  <Link to="/about" className="flex items-center">
                    Learn More <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
              </div>
              <div className="mt-8 flex items-center text-sm text-gray-500">
                <Shield className="h-5 w-5 text-bank-secondary mr-2" />
                <span>Your data is secure with our blockchain-based system</span>
              </div>
            </div>
            <div className="relative">
              <div className="absolute -top-6 -left-6 right-6 bottom-6 bg-bank-primary rounded-lg"></div>
              <div className="relative bg-white rounded-lg shadow-lg p-6">
                <h3 className="text-lg font-semibold mb-4 text-bank-primary">Blockchain-Secured Appointments</h3>
                <BlockchainVisual />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-bank-primary">Banking Services</h2>
            <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
              Schedule secure appointments for our comprehensive range of banking services
            </p>
          </div>
          
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-bank-light rounded-lg p-6 hover:shadow-md transition-shadow">
                <div className="inline-flex items-center justify-center p-3 bg-white rounded-full mb-4">
                  {service.icon}
                </div>
                <h3 className="text-xl font-semibold text-bank-primary mb-2">{service.title}</h3>
                <p className="text-gray-600">{service.description}</p>
                <Link 
                  to="/book" 
                  className="mt-4 inline-flex items-center text-bank-secondary hover:text-bank-primary"
                >
                  Book Now <ChevronRight className="ml-1 h-4 w-4" />
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Blockchain Features */}
      <BlockchainFeatures />

      {/* CTA Section */}
      <section className="bg-bank-primary py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white">Ready to experience modern banking?</h2>
          <p className="mt-4 text-lg text-bank-light max-w-3xl mx-auto">
            Book your appointment today and enjoy the security and transparency of our blockchain-enhanced banking services.
          </p>
          <div className="mt-8">
            <Button size="lg" className="bg-white text-bank-primary hover:bg-bank-light">
              <Link to="/book" className="flex items-center">
                Book Your Appointment <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
