
import React from 'react';
import { 
  Calendar, 
  Clock, 
  FileText, 
  Users, 
  CheckCircle2, 
  XCircle, 
  Link as LinkIcon, 
  Eye
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { Link } from 'react-router-dom';
import { format, addDays } from 'date-fns';

// Mock appointment data
const upcomingAppointments = [
  {
    id: '1',
    service: 'Loan Consultation',
    date: addDays(new Date(), 3),
    time: '10:00 AM',
    advisor: 'Sarah Johnson',
    status: 'confirmed',
    transactionId: '0x7c39485739d83ffa9382c89f82dba8920'
  },
  {
    id: '2',
    service: 'Financial Advice',
    date: addDays(new Date(), 7),
    time: '2:00 PM',
    advisor: 'Emily Williams',
    status: 'confirmed',
    transactionId: '0x5d93c7483a85b392f1942d85e99cf2b1'
  }
];

const pastAppointments = [
  {
    id: '3',
    service: 'Account Opening',
    date: addDays(new Date(), -14),
    time: '11:30 AM',
    advisor: 'John Smith',
    status: 'completed',
    transactionId: '0x1f39485e93d83fba6382c89f82dba8451'
  },
  {
    id: '4',
    service: 'Investment Planning',
    date: addDays(new Date(), -30),
    time: '3:15 PM',
    advisor: 'Michael Chen',
    status: 'cancelled',
    transactionId: '0x8b72c4a83f85b597f1932d75e11cf2c8'
  },
  {
    id: '5',
    service: 'Loan Consultation',
    date: addDays(new Date(), -45),
    time: '9:30 AM',
    advisor: 'Sarah Johnson',
    status: 'completed',
    transactionId: '0xc139485739a83eea9382c89f82dc8321'
  }
];

const DashboardPage = () => {
  return (
    <div className="py-10 px-4 bg-bank-light min-h-screen">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-bank-primary">Your Appointment Dashboard</h1>
            <p className="text-gray-600 mt-1">
              Track and manage your blockchain-secured banking appointments
            </p>
          </div>
          <Button className="bg-bank-primary hover:bg-bank-accent">
            <Link to="/book" className="flex items-center">
              New Appointment <Calendar className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Appointments
              </CardTitle>
              <FileText className="h-4 w-4 text-bank-secondary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{upcomingAppointments.length + pastAppointments.length}</div>
              <p className="text-xs text-gray-500">Appointments securely stored on blockchain</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Upcoming
              </CardTitle>
              <Calendar className="h-4 w-4 text-bank-secondary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{upcomingAppointments.length}</div>
              <p className="text-xs text-gray-500">Scheduled appointments</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Completed
              </CardTitle>
              <CheckCircle2 className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{pastAppointments.filter(a => a.status === 'completed').length}</div>
              <p className="text-xs text-gray-500">Successfully completed appointments</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Blockchain Integrity
              </CardTitle>
              <LinkIcon className="h-4 w-4 text-bank-secondary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">100%</div>
              <p className="text-xs text-gray-500">All records verified and intact</p>
            </CardContent>
          </Card>
        </div>
        
        <Tabs defaultValue="upcoming" className="space-y-4">
          <TabsList>
            <TabsTrigger value="upcoming">Upcoming Appointments</TabsTrigger>
            <TabsTrigger value="past">Past Appointments</TabsTrigger>
          </TabsList>
          
          <TabsContent value="upcoming" className="space-y-4">
            {upcomingAppointments.length > 0 ? (
              upcomingAppointments.map((appointment) => (
                <Card key={appointment.id} className="hover:shadow-md transition-shadow">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{appointment.service}</CardTitle>
                        <CardDescription className="flex items-center mt-1">
                          <Calendar className="h-4 w-4 mr-1" /> 
                          {format(appointment.date, 'EEEE, MMMM d, yyyy')} at {appointment.time}
                        </CardDescription>
                      </div>
                      <div className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-xs font-semibold">
                        {appointment.status === 'confirmed' ? 'Confirmed' : appointment.status}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-2 pb-2">
                    <div className="flex flex-wrap gap-4">
                      <div className="flex items-center text-sm text-gray-500">
                        <Users className="h-4 w-4 mr-1" /> 
                        <span>Advisor: {appointment.advisor}</span>
                      </div>
                      <div className="flex items-center text-sm text-gray-500">
                        <Clock className="h-4 w-4 mr-1" /> 
                        <span>{Math.floor((appointment.date.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} days until appointment</span>
                      </div>
                    </div>
                    <div className="mt-3 pt-3 border-t border-dashed border-gray-200">
                      <div className="flex items-start">
                        <LinkIcon className="h-4 w-4 mr-1 text-bank-secondary mt-0.5" />
                        <div>
                          <p className="text-xs font-medium text-gray-700">Blockchain Record</p>
                          <p className="text-xs font-mono text-gray-500 truncate max-w-md">
                            {appointment.transactionId}
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" size="sm">
                      <Eye className="h-4 w-4 mr-1" /> View Details
                    </Button>
                    <div className="space-x-2">
                      <Button variant="outline" size="sm" className="border-amber-500 text-amber-600 hover:bg-amber-50">
                        Reschedule
                      </Button>
                      <Button variant="outline" size="sm" className="border-red-500 text-red-600 hover:bg-red-50">
                        Cancel
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="pt-6 pb-6 text-center">
                  <div className="mx-auto mb-4 bg-muted rounded-full h-12 w-12 flex items-center justify-center">
                    <Calendar className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <h3 className="text-xl font-medium text-bank-primary mb-1">No Upcoming Appointments</h3>
                  <p className="text-sm text-gray-500 mb-4">You don't have any upcoming appointments scheduled.</p>
                  <Button className="bg-bank-primary hover:bg-bank-accent">
                    <Link to="/book">Book an Appointment</Link>
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>
          
          <TabsContent value="past" className="space-y-4">
            {pastAppointments.map((appointment) => (
              <Card key={appointment.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle>{appointment.service}</CardTitle>
                      <CardDescription className="flex items-center mt-1">
                        <Calendar className="h-4 w-4 mr-1" /> 
                        {format(appointment.date, 'EEEE, MMMM d, yyyy')} at {appointment.time}
                      </CardDescription>
                    </div>
                    <div className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      appointment.status === 'completed' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {appointment.status === 'completed' ? 'Completed' : 'Cancelled'}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-2 pb-2">
                  <div className="flex flex-wrap gap-4">
                    <div className="flex items-center text-sm text-gray-500">
                      <Users className="h-4 w-4 mr-1" /> 
                      <span>Advisor: {appointment.advisor}</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-500">
                      <Clock className="h-4 w-4 mr-1" /> 
                      <span>{Math.abs(Math.floor((appointment.date.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)))} days ago</span>
                    </div>
                  </div>
                  <div className="mt-3 pt-3 border-t border-dashed border-gray-200">
                    <div className="flex items-start">
                      <LinkIcon className="h-4 w-4 mr-1 text-bank-secondary mt-0.5" />
                      <div>
                        <p className="text-xs font-medium text-gray-700">Blockchain Record</p>
                        <p className="text-xs font-mono text-gray-500 truncate max-w-md">
                          {appointment.transactionId}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" size="sm">
                    <Eye className="h-4 w-4 mr-1" /> View Details
                  </Button>
                  <div className="ml-auto">
                    {appointment.status === 'completed' && (
                      <Button variant="outline" size="sm" className="border-bank-primary text-bank-primary hover:bg-bank-light">
                        Schedule Similar
                      </Button>
                    )}
                  </div>
                </CardFooter>
              </Card>
            ))}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default DashboardPage;
