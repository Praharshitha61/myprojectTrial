
import React from 'react';
import { Shield, Lock, Clock, Layers, FileCheck, RefreshCw } from 'lucide-react';

const features = [
  {
    title: 'Immutable Records',
    description: 'All appointment records are stored on blockchain and cannot be altered or deleted, ensuring data integrity.',
    icon: <Lock className="h-6 w-6 text-bank-secondary" />
  },
  {
    title: 'Smart Contracts',
    description: 'Automated appointment scheduling and confirmation through blockchain-based smart contracts.',
    icon: <FileCheck className="h-6 w-6 text-bank-secondary" />
  },
  {
    title: 'Enhanced Security',
    description: 'Decentralized architecture protects your personal and financial information from cyber threats.',
    icon: <Shield className="h-6 w-6 text-bank-secondary" />
  },
  {
    title: 'Transparent History',
    description: 'Complete visibility of your appointment history with immutable timestamps and details.',
    icon: <Clock className="h-6 w-6 text-bank-secondary" />
  },
  {
    title: 'Distributed Ledger',
    description: 'Information is distributed across multiple nodes, eliminating single points of failure.',
    icon: <Layers className="h-6 w-6 text-bank-secondary" />
  },
  {
    title: 'Real-Time Updates',
    description: 'Instant synchronization of appointment data across all authorized participants.',
    icon: <RefreshCw className="h-6 w-6 text-bank-secondary" />
  }
];

const BlockchainFeatures = () => {
  return (
    <div className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-bank-primary sm:text-4xl">
            Blockchain-Enhanced Banking
          </h2>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 mx-auto">
            Experience the security and transparency of blockchain technology in your banking journey.
          </p>
        </div>
        
        <div className="mt-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="bg-bank-light rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                <div className="inline-flex items-center justify-center rounded-md bg-bank-primary bg-opacity-10 p-3 mb-5">
                  {feature.icon}
                </div>
                <h3 className="text-lg font-medium text-bank-primary">{feature.title}</h3>
                <p className="mt-2 text-base text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlockchainFeatures;
