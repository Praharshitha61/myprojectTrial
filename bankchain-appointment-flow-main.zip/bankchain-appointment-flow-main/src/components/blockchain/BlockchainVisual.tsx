
import React from 'react';
import { Shield, Lock } from 'lucide-react';

const BlockchainVisual = () => {
  return (
    <div className="w-full overflow-hidden py-6">
      <div className="flex justify-between items-center space-x-4 md:space-x-6 overflow-x-auto pb-4 px-4">
        {Array.from({ length: 5 }).map((_, index) => (
          <div 
            key={index}
            className={`flex-shrink-0 bg-white rounded-lg shadow-md p-4 border-2 border-bank-secondary w-56 relative animate-block-animation`}
            style={{ animationDelay: `${index * 0.3}s` }}
          >
            <div className="absolute -top-3 -right-3 bg-bank-primary text-white p-2 rounded-full">
              <Lock className="h-4 w-4" />
            </div>
            <h4 className="font-semibold text-bank-primary mb-2">Block #{index + 1}</h4>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-gray-500">Time:</span>
                <span className="font-mono">{new Date(Date.now() - (index * 600000)).toLocaleTimeString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">User:</span>
                <span className="font-mono">0x{Math.random().toString(16).slice(2, 8)}...</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Service:</span>
                <span className="font-mono">{['Loan', 'Account', 'Advice', 'Investment', 'Review'][index % 5]}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Hash:</span>
                <span className="font-mono truncate">0x{Math.random().toString(16).slice(2, 10)}...</span>
              </div>
            </div>
            <div className="mt-3 pt-2 border-t border-dashed border-gray-200 flex justify-between items-center">
              <div className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                Verified
              </div>
              <Shield className="h-4 w-4 text-bank-primary" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BlockchainVisual;
