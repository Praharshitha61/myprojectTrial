
import React from 'react';
import { Link } from 'react-router-dom';
import { Shield, Facebook, Twitter, Instagram, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-bank-primary text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <div className="h-10 w-10 bg-white rounded-md flex items-center justify-center">
                <Shield className="h-6 w-6 text-bank-primary" />
              </div>
              <span className="ml-2 text-xl font-bold text-white">NaviBank</span>
            </div>
            <p className="text-sm text-gray-300">
              Secure, transparent banking services enhanced with blockchain technology for modern clients.
            </p>
            <div className="flex mt-4 space-x-3">
              <a href="#" className="text-gray-300 hover:text-white">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-300 hover:text-white">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-300 hover:text-white">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider mb-4">Services</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/book" className="text-gray-300 hover:text-white text-sm">
                  Account Opening
                </Link>
              </li>
              <li>
                <Link to="/book" className="text-gray-300 hover:text-white text-sm">
                  Loan Consultation
                </Link>
              </li>
              <li>
                <Link to="/book" className="text-gray-300 hover:text-white text-sm">
                  Financial Advice
                </Link>
              </li>
              <li>
                <Link to="/book" className="text-gray-300 hover:text-white text-sm">
                  Investment Planning
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-300 hover:text-white text-sm">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/book" className="text-gray-300 hover:text-white text-sm">
                  Book Appointment
                </Link>
              </li>
              <li>
                <Link to="/dashboard" className="text-gray-300 hover:text-white text-sm">
                  Dashboard
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-300 hover:text-white text-sm">
                  About Blockchain
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider mb-4">Contact Us</h3>
            <ul className="space-y-2">
              <li className="flex items-start">
                <MapPin className="h-5 w-5 mr-2 text-bank-secondary" />
                <span className="text-sm text-gray-300">123 Finance Street, Banking District, NY 10001</span>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 mr-2 text-bank-secondary" />
                <span className="text-sm text-gray-300">+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 mr-2 text-bank-secondary" />
                <span className="text-sm text-gray-300">support@navibank.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-gray-700">
          <p className="text-sm text-gray-300 text-center">
            &copy; {new Date().getFullYear()} NaviBank. All rights reserved. Powered by blockchain technology.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
