
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { 
  Menu, 
  X, 
  ChevronDown,
  Calendar,
  BarChart,
  Shield,
  UserCircle
} from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const Navbar = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  return (
    <nav className="bg-white shadow-sm border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 flex items-center">
              <div className="h-10 w-10 bg-bank-primary rounded-md flex items-center justify-center">
                <Shield className="h-6 w-6 text-white" />
              </div>
              <span className="ml-2 text-xl font-bold text-bank-primary">NaviBank</span>
            </Link>
            <div className="hidden md:ml-6 md:flex md:space-x-8">
              <Link to="/" className="inline-flex items-center px-1 pt-1 text-sm font-medium text-bank-primary">
                Home
              </Link>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="inline-flex items-center px-1 pt-1 text-sm font-medium text-gray-700 hover:text-bank-primary">
                    Services <ChevronDown className="ml-1 h-4 w-4" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-56">
                  <DropdownMenuItem>
                    <Link to="/book" className="w-full">Account Opening</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link to="/book" className="w-full">Loan Consultation</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link to="/book" className="w-full">Financial Advice</Link>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              
              <Link to="/book" className="inline-flex items-center px-1 pt-1 text-sm font-medium text-gray-700 hover:text-bank-primary">
                Book Appointment
              </Link>
              
              <Link to="/dashboard" className="inline-flex items-center px-1 pt-1 text-sm font-medium text-gray-700 hover:text-bank-primary">
                Dashboard
              </Link>

              <Link to="/about" className="inline-flex items-center px-1 pt-1 text-sm font-medium text-gray-700 hover:text-bank-primary">
                About Blockchain
              </Link>
            </div>
          </div>
          
          <div className="hidden md:flex items-center">
            <Button variant="ghost" size="sm" className="mr-2">
              <UserCircle className="h-5 w-5 mr-1" />
              Sign In
            </Button>
            <Button size="sm" className="bg-bank-primary hover:bg-bank-accent">
              Get Started
            </Button>
          </div>
          
          <div className="flex items-center md:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-700 hover:text-bank-primary hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-bank-primary"
            >
              {mobileMenuOpen ? (
                <X className="block h-6 w-6" aria-hidden="true" />
              ) : (
                <Menu className="block h-6 w-6" aria-hidden="true" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className={cn("md:hidden", mobileMenuOpen ? "block" : "hidden")}>
        <div className="pt-2 pb-3 space-y-1">
          <Link
            to="/"
            className="block pl-3 pr-4 py-2 border-l-4 border-bank-primary text-base font-medium text-bank-primary bg-bank-light"
            onClick={() => setMobileMenuOpen(false)}
          >
            Home
          </Link>
          <Link
            to="/book"
            className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-700 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-900"
            onClick={() => setMobileMenuOpen(false)}
          >
            Book Appointment
          </Link>
          <Link
            to="/dashboard"
            className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-700 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-900"
            onClick={() => setMobileMenuOpen(false)}
          >
            Dashboard
          </Link>
          <Link
            to="/about"
            className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-700 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-900"
            onClick={() => setMobileMenuOpen(false)}
          >
            About Blockchain
          </Link>
          <div className="pt-4 pb-3 border-t border-gray-200">
            <div className="flex items-center px-4">
              <Button variant="ghost" size="sm" className="mr-2 w-full justify-center">
                Sign In
              </Button>
              <Button size="sm" className="bg-bank-primary hover:bg-bank-accent w-full justify-center">
                Get Started
              </Button>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
